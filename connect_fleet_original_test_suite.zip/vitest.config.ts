import { defineConfig } from "vitest/config";
import react from "@vitejs/plugin-react-swc";
import path from "path";

export default defineConfig({
  plugins: [react()],
  test: {
    environment: "jsdom",
    globals: true,
    setupFiles: ["./src/test/setup.ts"],
    include: ["src/**/*.{test,spec}.{ts,tsx}"],
    // Radix DropdownMenu interaction tests flush many microtasks/timers under
    // act(); raise the per-test ceiling so the worker isn't flagged as
    // unresponsive (which surfaces as a flaky "Timeout calling onTaskUpdate"
    // RPC error even though every test passes).
    testTimeout: 30000,
    hookTimeout: 30000,
  },
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },
});
